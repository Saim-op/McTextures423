# Installation

1. [Download this plugin](https://github.com/Automattic/super-cool-adinserter-plugin/archive/trunk.zip) and save it to your WordPress installation's `wp-content/plugins/` directory in a folder named `super-cool-ad-inserter-plugin`
2. Follow the [manual plugin installation instructions](https://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation) in the WordPress documentation to activate the plugin.
3. [Configure the plugin](./configuration.md).
