<?php

class ScaipTestFunctions extends WP_UnitTestCase {
	function test_scaip_deactivation() {
		$this->markTestIncomplete( 'This test has not been implemented yet.' );
	}
}
