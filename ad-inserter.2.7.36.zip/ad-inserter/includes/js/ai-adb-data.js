var ai_adb_active = false;
var ai_adb_counter = 0;
var ai_adb_act_cookie_name = "aiADB";
var ai_adb_pgv_cookie_name = "aiADB_PV";
var ai_adb_page_redirection_cookie_name = "aiADB_PR";

var ai_adb_overlay = AI_ADB_OVERLAY_WINDOW;
var ai_adb_message_window = AI_ADB_MESSAGE_WINDOW;
var ai_adb_message_undismissible = AI_FUNCB_GET_UNDISMISSIBLE_MESSAGE;
var ai_adb_message_cookie_lifetime = AI_FUNCT_GET_NO_ACTION_PERIOD;
var ai_adb_devices = AI_FUNC_GET_ADB_DEVICES;
var ai_adb_action = AI_FUNC_GET_ADB_ACTION;
var ai_adb_page_views = "AI_FUNC_GET_DELAY_ACTION";
var ai_adb_selectors = "AI_ADB_SELECTORS";
var ai_adb_redirection_url = "AI_ADB_REDIRECTION_PAGE";

var ai_block_class = 'AI_FUNC_GET_BLOCK_CLASS_NAME';
var ai_adb_content_css_begin_class = 'AI_ADB_CONTENT_CSS_BEGIN_CLASS';
var ai_adb_content_css_end_class = 'AI_ADB_CONTENT_CSS_END_CLASS';
var ai_adb_content_delete_begin_class = 'AI_ADB_CONTENT_DELETE_BEGIN_CLASS';
var ai_adb_content_delete_end_class = 'AI_ADB_CONTENT_DELETE_END_CLASS';
var ai_adb_content_replace_begin_class = 'AI_ADB_CONTENT_REPLACE_BEGIN_CLASS';
var ai_adb_content_replace_end_class = 'AI_ADB_CONTENT_REPLACE_END_CLASS';
var ai_adb_cookie_value = 'AI_CONST_AI_ADB_COOKIE_VALUE';
var ai_adb_name_1 = 'AI_CONST_AI_ADB_1_NAME';
var ai_adb_name_2 = 'AI_CONST_AI_ADB_2_NAME';
var ai_adb_attribute = AI_ADB_ATTR_NAME;

var ai_adb_message_code_1 = function () {window.AI_ADB_STATUS_MESSAGE=1}
var ai_adb_message_code_2 = function () {window.AI_ADB_STATUS_MESSAGE=2}
var ai_adb_message_code_3 = function () {window.AI_ADB_STATUS_MESSAGE=3}
var ai_adb_message_code_4 = function () {window.AI_ADB_STATUS_MESSAGE=4}
var ai_adb_message_code_5 = function () {window.AI_ADB_STATUS_MESSAGE=5}
var ai_adb_message_code_6 = function () {window.AI_ADB_STATUS_MESSAGE=6}

