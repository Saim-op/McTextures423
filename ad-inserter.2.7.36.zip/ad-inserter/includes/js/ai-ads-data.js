var ai_adsense_ad_names = [];
var ai_preview_window = typeof ai_preview !== 'undefined';
var ai_ajax_url = 'AI_AJAXURL';
var ai_nonce = 'AI_NONCE';
